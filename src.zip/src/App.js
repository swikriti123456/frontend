import "./App.css";
import React from "react";
import { Router, Switch, Route } from "react-router-dom";
import BoardAdmin from "./Components/Admin";
import BoardModerator from "./Components/Moderator";
import Home from "./Components/Home";
import Login from "./Components/Login";
import BoardUser from "./Components/User";
import Registration from "./Components/Registration";
import Profile from "./Components/Profile";
import Navbar from "./Components/Navbar";

function App() {
  return (
    <Router>
      <Navbar />
      <div className="container mt-3">
        <Switch>
          <Route exact path={["/", "/home"]} component={Home}></Route>
          <Route exact path="/login" component={Login}></Route>
          <Route exact path="/register" component={Registration}></Route>
          <Route exact path="/profile" component={Profile}></Route>
          <Route path="/user" component={BoardUser}></Route>
          <Route path="/mod" component={BoardModerator}></Route>
          <Route path="/admin" component={BoardAdmin}></Route>
        </Switch>
      </div>
    </Router>
  );
}

export default App;
